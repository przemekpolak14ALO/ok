const express = require("express");
const router = express.Router();
const fs = require("fs").promises;
const path = require("path");

const filePath = path.join(__dirname, "../users.json");

const getUsers = async () => {
    const users = await fs.readFile(filePath, "utf-8");
    return JSON.parse(users);
};

const saveUsers = async (users) => {
    await fs.writeFile(filePath, JSON.stringify(users, null, 2), "utf-8");
};

router.get("/", async (req, res) => {
    try {
        const users = await getUsers();
        res.json(users);
    } catch (err) {
        res.status(500).json({ message: "Błąd odczytu pliku JSON", error: err.message });
    }
});

router.get("/:id", async (req, res) => {
    try {
        const users = await getUsers();
        const userId = parseInt(req.params.id);
        const user = users.find(u => u.id === userId);

        if (!user) {
            return res.status(404).json({ message: "Użytkownik nie istnieje" });
        }
        res.json(user);
    } catch (err) {
        res.status(500).json({ message: "Błąd odczytu pliku JSON", error: err.message });
    }
});

router.post("/", async (req, res) => {
    try {
        const users = await getUsers();
        const newUser = {
            id: users.length,
            username: req.body.username
        };
        users.push(newUser);
        await saveUsers(users);
        res.status(201).json(newUser);
    } catch (err) {
        res.status(500).json({ message: "Błąd zapisu pliku JSON", error: err.message });
    }
});

router.put("/:id", async (req, res) =>{
    try{
        const users = await getUsers();
        const userId = parseInt(req.params.id);
        const index = users.findIndex(u => u.id === userId);

        if(index === -1){
            return res.status(404).json({message: "użytkownik nie istnieje"});
        }

        users[index] = {
            id: userId,
            username: req.body.username
        };

        await saveUsers(users);
        res.json(users[index]);
    } catch(err){
        res.status(500).json({ message: "Błąd serwera", error: err.message })
    };
});

router.patch("/:id", async (req, res) => {
    try{
        const users = await getUsers();
        const userId = parseInt(req.params.id);
        const user = users.find(u=> u.id === userId);

        if(!user){
            return res.status(404).json({message: "użytkownik nie istnieje"});
        };

        if(req.body.username !== undefined){
            user.username = req.body.username;
        };

        await saveUsers(users);
        res.json(user);
    } catch (err){
        res.status(500).json({ message: "Błąd serwera", error: err.message});
    };
});

router.delete("/:id", async (req, res) => {
    try{
        const users = await getUsers();
        const userId = parseInt(req.params.id);

        const filteredUsers = users.filter(u => u.id !== userId);

        if(users.length === filteredUsers.length){
            return res.status(404).json({message: "użytkownik nie istnieje"});
        };

        await saveUsers(filteredUsers);
        res.json({ message: `Użytkownik o ID ${userId} został usunięty` });
    } catch(err){
        res.status(500).json({ message: "Błąd serwera", error: err.message });
    };
});

module.exports = router;