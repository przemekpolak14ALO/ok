const express = require("express");
const router = express.Router();
const fs = require("fs").promises;

const getUsers = async()=>{
    const users =await fs.readFile("../users.json","utf-8");
    return JSON.parse(users);
}
const saveUsers = async(users)=>{
    await fs.writeFile("../users.json", JSON.stringify(users), "utf-8");

};

router.get("/", async(req, res)=> {
    const users = await getUsers();
    res.json(users);
});

router.post("/", async(req ,res) =>{
    const users = await this.getUsers();
    const newUser = {
        id : users.lenght,
        username : req.body.username
    };
    users.push(newUser);
    res.status(201).json(newUser);
    saveUsers(users);
});

module.exports = router;